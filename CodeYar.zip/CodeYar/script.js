
// تعیین فونت Vazir به عنوان فونت پیش‌فرض برای متن‌ها
document.body.style.fontFamily = "Vazirmatn, sans-serif";
// جستجو در گوگل
document.getElementById("searchInput").addEventListener("keypress", function(event) {
    if (event.key === "Enter") {
        searchGoogle();
    }
});

document.getElementById("searchButton").addEventListener("click", function() {
    searchGoogle();
});

function searchGoogle() {
    var query = document.getElementById("searchInput").value;
    if (query.trim() !== "") {
        var googleSearchUrl = "https://www.google.com/search?q=" + encodeURIComponent(query);
        window.location.href = googleSearchUrl;
    }
}

document.addEventListener("DOMContentLoaded", function() {
    loadBookmarks();
    
// تنظیم دکمه ذخیره بوکمارک
document.getElementById("saveBookmarkBtn").addEventListener("click", function() {
    var siteName = document.getElementById("bookmarkName").value;
    var siteLink = document.getElementById("bookmarkLink").value;
    if (siteName && siteLink) {
        var bookmark = {
            name: siteName,
            link: siteLink,
            icon: getWebsiteIcon(siteLink)
        };
        saveBookmark(bookmark);
        closeModal(); // بستن مدال پس از ذخیره
    } else {
        alert("لطفاً اطلاعات معتبر وارد کنید!");
    }
});


    // الگویی برای اتصال دکمه بستن مدال به تابع closeModal
    var closeButton = document.querySelector(".close");
    if (closeButton) {
        closeButton.addEventListener("click", closeModal);
    }
// تابع بستن مدال
function closeModal() {
    document.getElementById("myModal").style.display = "none";
}


// تابع ذخیره بوکمارک
function saveBookmark(bookmark) {
    var bookmarks = JSON.parse(localStorage.getItem("bookmarks")) || [];
    var bookmarkExists = bookmarks.some(function(existingBookmark) {
        return existingBookmark.name === bookmark.name && existingBookmark.link === bookmark.link;
    });

    // بررسی وجود "http://" یا "https://" در لینک
    var httpRegex = /^(https?:\/\/)/;
    if (!httpRegex.test(bookmark.link)) {
        // اگر لینک "http://" یا "https://" ندارد، آن را به لینک اضافه کنید
        bookmark.link = "http://" + bookmark.link;
    }

    if (!bookmarkExists) {
        bookmarks.push(bookmark);
        localStorage.setItem("bookmarks", JSON.stringify(bookmarks));
        loadBookmarks();
    } else {
        alert("این بوکمارک قبلاً ذخیره شده است!");
    }
}



});

function loadBookmarks() {
    var bookmarks = JSON.parse(localStorage.getItem("bookmarks")) || [];
    var bookmarksContainer = document.getElementById("bookmarksContainer");
    bookmarksContainer.innerHTML = ""; // حذف بوکمارک‌های قبلی

    bookmarks.forEach(function(bookmark) {
        var bookmarkTile = document.createElement("div");
        bookmarkTile.classList.add("bookmark-tile");

        var bookmarkIcon = document.createElement("img");
        bookmarkIcon.classList.add("bookmark-icon");
        bookmarkIcon.src = bookmark.icon;
        bookmarkTile.appendChild(bookmarkIcon);

        var bookmarkLink = document.createElement("a");
        bookmarkLink.classList.add("bookmark-link");
        bookmarkLink.href = bookmark.link;
        bookmarkLink.textContent = bookmark.name;
        bookmarkTile.appendChild(bookmarkLink);

        var actionButtons = document.createElement("div");
        actionButtons.classList.add("action-buttons");

        var editButton = document.createElement("button");
        editButton.classList.add("action-button", "edit-button2");
        editButton.innerHTML = '<i class="fas  fa-edit"></i> ویرایش';
        editButton.onclick = function() {
            editBookmark(bookmark);
        };
        actionButtons.appendChild(editButton);
        
        var deleteButton = document.createElement("button");
        deleteButton.classList.add("action-button", "delete-button2");
        deleteButton.innerHTML = '<i class="fas fa-trash"></i> حذف';
        deleteButton.onclick = function() {
            deleteBookmark(bookmark);
        };
        actionButtons.appendChild(deleteButton);

        bookmarkTile.appendChild(actionButtons);

        bookmarksContainer.appendChild(bookmarkTile);
    });

    // اضافه کردن دکمه اضافه کردن بوکمارک
    if (bookmarks.length < 6) {
        var addBookmarkButton = document.createElement("div");
        addBookmarkButton.classList.add("bookmark-tile");
        addBookmarkButton.textContent = "+";
        addBookmarkButton.onclick = function() {
            var modal = document.getElementById("myModal");
            var modalContent = document.querySelector('.modal-content');
            modal.style.display = "block";
            modal.classList.add("fadeIn");
    
            // نمایش مدال
            modalContent.style.display = "block";
        };
        bookmarksContainer.appendChild(addBookmarkButton);
    }
    
}

// تابع ویرایش بوکمارک
function editBookmark(bookmark) {
    var newName = prompt("Please enter the new name for the bookmark:", bookmark.name);
    var newLink = prompt("Please enter the new link for the bookmark:", bookmark.link);
    if (newName !== null && newName !== "" && newLink !== null && newLink !== "") { 
        // اگر نام و لینک جدید وارد شده‌اند
        bookmark.name = newName; 
        bookmark.link = newLink; 
        updateBookmark(bookmark); // ذخیره تغییرات
        loadBookmarks(); // بارگذاری مجدد بوکمارک‌ها برای نمایش تغییرات
    }
}

// تابع حذف بوکمارک
function deleteBookmark(bookmark) {
    var confirmation = confirm("Are you sure you want to delete this bookmark?");
    if (confirmation) {
        var bookmarks = JSON.parse(localStorage.getItem("bookmarks")) || [];
        var index = bookmarks.findIndex(function(item) {
            return item.name === bookmark.name && item.link === bookmark.link;
        });
        bookmarks.splice(index, 1);
        localStorage.setItem("bookmarks", JSON.stringify(bookmarks));
        loadBookmarks();
    }
}

// تابع بدست آوردن آیکون وب‌سایت
function getWebsiteIcon(websiteUrl) {
    var siteIcon = "https://www.google.com/s2/favicons?domain=" + websiteUrl;
    return siteIcon;
}

// تابع ذخیره بوکمارک
function saveBookmark(bookmark) {
    var bookmarks = JSON.parse(localStorage.getItem("bookmarks")) || [];
    var bookmarkExists = bookmarks.some(function(existingBookmark) {
        return existingBookmark.name === bookmark.name && existingBookmark.link === bookmark.link;
    });
    if (!bookmarkExists) {
        bookmarks.push(bookmark);
        localStorage.setItem("bookmarks", JSON.stringify(bookmarks));
        loadBookmarks();
    } else {
        alert("This bookmark already exists!");
    }
}

// ابزار بارگیری ترند های کد نویسانه
$(document).ready(function() {
    fetchTrends(); // بارگیری ترندها هنگام بارگیری صفحه

    $("#searchButton").on("click", function() {
        var query = $("#searchInput").val().trim();
        if (query !== "") {
            window.location.href = "https://www.google.com/search?q=" + encodeURIComponent(query);
        }
    });

    function fetchTrends() {
        $.ajax({
            url: "trends.json",
            method: "GET",
            dataType: "json",
            success: function(data) {
                var trendsHTML = "<p class='trend-p' style='font-family: Vazirmatn, sans-serif;'> کد نویسانه ها:</p>";
                data.forEach(function(trend) {
                    trendsHTML += "<a class='trends-item trend-p' href='https://www.google.com/search?q=" + encodeURIComponent(trend) + "' style='font-family: Vazirmatn, sans-serif;'>" + trend + "</a>";
                });
                $("#trendsContainer").html(trendsHTML);
            },
            error: function(xhr, status, error) {
                console.log("خطا در دریافت ترندها: ", error);
            }
        });
    }    

    
}); 
//ابزار بارگیری ابزارهای کد یار
$(document).ready(function() {
    fetchTrends(); // بارگیری ابزار ها هنگام بارگیری صفحه

    $("#searchButton").on("click", function() {
        var query = $("#searchInput").val().trim();
        if (query !== "") {
            window.location.href = "https://www.google.com/search?q=" + encodeURIComponent(query);
        }
    });

      function fetchTrends() {
        $.ajax({
            url: "tools.json",
            method: "GET",
            dataType: "json",
            success: function(data) {
                var trendsHTML = "";
                data.forEach(function(trend) {
                    trendsHTML += "<div class='tools-item'>";
                    trendsHTML += "<img src='" + trend.image + "' alt='" + trend.title + "' style='width: 50px; height: 50px;     border-radius: 10px;'>";
                    trendsHTML += "<a class='tools-item-text' href='" + trend.link + "' style=' text-decoration: none; font-family: Vazirmatn, sans-serif; font-size:16px; margin-top:13px;'>" + trend.title + "</a>";
                    trendsHTML += "</div>";
                });
                $("#containers1").html(trendsHTML);
            },
            error: function(xhr, status, error) {
                console.log("خطا در دریافت ابزارها: ", error);
            }
        });
    } 

    
}); 
//سامانه تاریخ و ساعت
async function getIranianDate() {
    try {
        const response = await fetch('https://api.keybit.ir/time/');
        const data = await response.json();
        const iranianDate = {
            year: data.date.year.number.fa,
            month: data.date.month.name,
            day: data.date.day.number.fa
        };
        return iranianDate;
    } catch (error) {
        console.error('Error fetching Iranian date:', error.message);
        return null;
    }
}

async function updateIranianDate() {
    const iranianDate = await getIranianDate();
    if (iranianDate) {
        document.getElementById('iranian-year').textContent = iranianDate.year;
        document.getElementById('iranian-month').textContent = iranianDate.month;
        document.getElementById('iranian-day').textContent = iranianDate.day;
    }
}

setInterval(updateIranianDate, 1000); // به روزرسانی هر ثانیه

updateIranianDate(); // نمایش تاریخ به طور اولیه

async function updateGreeting() {
    const now = new Date();
    const hour = now.getHours();
    let greeting = '';
    let imageSrc = ''; // آدرس تصویر

    if (hour >= 5 && hour < 12) {
        greeting = 'صبحتون خوش';
        imageSrc = './assest/img/ai-morning.png'; // تصویر صبح
    } else if (hour >= 12 && hour < 14) {
        greeting = 'ظهر بخیر';
        imageSrc = './assest/img/ai-after.png'; // تصویر ظهر
    } else if (hour >= 14 && hour < 17) {
        greeting = 'روز خوشی داشتی باشید';
        imageSrc = './assest/img/ai-rooz.png'; // تصویر عصر
    } else if (hour >= 17 && hour < 17.30) {
        greeting = 'عصر خوش';
        imageSrc = './assest/img/ai-asre.png'; // تصویر عصر
    } else if (hour >= 17.31 && hour < 24) {
        greeting = 'شب رویایی داشته باشید';
        imageSrc = './assest/img/ai-night.png'; // تصویر شب
    } 
    
    else {
        greeting = 'شبتون خوش';
        imageSrc = './assest/img/ai-night.png'; // تصویر شب
    }

    document.getElementById('greetings').textContent = greeting;
    document.getElementById('image').src = imageSrc;
} 


function updateClock() {
    const now = new Date();
    const hours = String(now.getHours()).padStart(2, '0');
    const minutes = String(now.getMinutes()).padStart(2, '0');
    const seconds = String(now.getSeconds()).padStart(2, '0');
    const timeString = `${hours}:${minutes}:${seconds}`;
    document.getElementById('clock').textContent = timeString;

    // با استفاده از requestAnimationFrame ساعت به صورت لحظه‌ای به‌روزرسانی می‌شود
    requestAnimationFrame(updateClock);
}

// اولین فراخوانی برای شروع به روزرسانی ساعت
updateClock();

// به روزرسانی تاریخ شمسی و تبریک زمان مورد نظر شما
updateGreeting();
// //لینک دندوم دکمه بالا
//         // آرایه از اشیاء با متن و لینک متفاوت
//         const buttons = [
//             { text: "عید نزدیکه فالت بگیروم", link: "https://faal.pop-music.ir/" },
//             { text: "موزیک گوش کنیم", link: "https://pop-music.ir/" }
//         ];

//         // انتخاب یک شیء به صورت تصادفی
//         const randomIndex = Math.floor(Math.random() * buttons.length);
//         const randomButton = buttons[randomIndex];

//         // تنظیم متن و لینک رندم در دکمه
//         document.getElementById("randomButton").textContent = randomButton.text;
//         document.getElementById("randomButton").href = randomButton.link;


// دارک

// تابع برای ذخیره وضعیت تاریکی در Local Storage
function saveDarkModeState(isDarkMode) {
    localStorage.setItem('darkMode', isDarkMode);
}

// تابع برای بازیابی وضعیت تاریکی از Local Storage
function loadDarkModeState() {
    return JSON.parse(localStorage.getItem('darkMode'));
}

// تابعی برای تغییر حالت تاریکی
function toggleDarkMode() {
    document.body.classList.toggle('dark-mode');

    // ذخیره وضعیت تاریکی بعد از تغییر
    saveDarkModeState(document.body.classList.contains('dark-mode'));

    // بررسی وضعیت تاریکی بعد از تغییر
    if (document.body.classList.contains('dark-mode')) {
        // اگر وضعیت تاریکی فعال باشد، رنگ آیکون‌ها را به حالت تاریک تغییر دهید
        document.documentElement.style.setProperty('--icon-color-light', '#ffffff');
        document.documentElement.style.setProperty('--icon-color-dark', '#000000');
    } else {
        // اگر وضعیت تاریکی غیرفعال باشد، رنگ آیکون‌ها را به حالت روشن تغییر دهید
        document.documentElement.style.setProperty('--icon-color-light', '#000000');
        document.documentElement.style.setProperty('--icon-color-dark', '#ffffff');
    }
}

// دریافت دکمه تغییر حالت تاریک/روشن بودن صفحه
const darkModeToggle = document.getElementById('darkModeToggle');

// اضافه کردن یک event listener برای کلیک بر روی دکمه
darkModeToggle.addEventListener('click', toggleDarkMode);

// بررسی وضعیت تاریکی از Local Storage و تنظیم آن
const isDarkMode = loadDarkModeState();
if (isDarkMode) {
    document.body.classList.add('dark-mode');
}
